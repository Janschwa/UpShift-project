<?php
require 'vendor/autoload.php';
require 'env.php';
require 'database/ConnectionFactory.php';
require 'tasks/TaskService.php';




$app = new \Slim\Slim();

// http://hostname/api/

$app->get('/', function() use ( $app ) {
    echo "Welcome to Task REST API";
});

$app->get('/tasks/', function() use ( $app ) {
    $tasks = TaskService::listTasks();
    $app->response()->header('Content-Type', 'application/json');
    echo json_encode($tasks);
});


$app->get('/tasks/:id', function($id) use ( $app ) {
    $task = TaskService::getById($id);
    
    if($task) {
        $app->response()->header('Content-Type', 'application/json');
        echo json_encode($task);
    }
    else {
        $app->response()->setStatus(204);
    }
});


$app->post('/tasks/', function() use ( $app ) {
    $taskJson = $app->request()->getBody();
    $newTask = json_decode($taskJson, true);
    if($newTask) {
        $task = TaskService::add($newTask);
        echo json_encode($task);
    }
    else {
        $app->response->setStatus(400);
        echo json_encode(['error' => "Invalid JSON"]);
    }
});


$app->put('/tasks/', function() use ( $app ) {
    $taskJson = $app->request()->getBody();
    $updatedTask = json_decode($taskJson, true);
    
    if($updatedTask && $updatedTask['id']) {
        if(TaskService::update($updatedTask)) {
          echo json_encode($updatedTask);
        }
        else {
          $app->response->setStatus('404');
            echo json_encode(['error' => "Task Not Found"]);
        }
    }
    else {
        $app->response->setStatus(400);
        echo json_encode(['error' => "Invalid JSON"]);;
    }
});


$app->delete('/tasks/:id', function($id) use ( $app ) {
    if(TaskService::delete($id)) {
      echo json_encode(['success' => true]);
    }
    else {
      $app->response->setStatus('404');
        echo json_encode(['error' => "Task Not Found"]);
    }
});

$app->run();
