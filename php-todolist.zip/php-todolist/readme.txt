Setup:

Import Database from `database/task.sql`
Composer install in projects/api directory
Rename `env.example.php` to `env.php`
Update `env.php` with your mysql settings

API CALLS:

Fetch All Tasks:

HTTP GET http://domain/api/tasks
RESPONSE 200 OK
[
  {
    "id": 1,
    "description": "Learn REST",
    "done": false
  },
  {
    "id": 2,
    "description": "Learn JavaScript",
    "done": false
  },
  {
    "id": 3,
    "description": "Learn English",
    "done": false
  }
]

Get TaskByID:
HTTP GET http://domain/api/tasks/1
RESPONSE 200 OK
{
  "id": 1,
  "description": "Learn REST",
  "done": false
}

RESPONSE 204 NO CONTENT












Create Task:

HTTP POST http://domain/api/tasks
REQUEST Body
{
  "description": "Learn REST",
}

RESPONSE 200 OK 
Body
{
  “id”: 1	
  "description": "Learn REST",
}


Update Task:

HTTP PUT http://domain/api/tasks/1
REQUEST Body
{
  "id": 1,
  "description": "Learn REST",
  "done": false
}

RESPONSE 200 OK
{
  "id": 1,
  "description": "Learn REST",
  "done": false
}

Delete Taske:

HTTP DELETE http://domain/api/tasks/1
RESPONSE 200 OK

RESPONSE 404
{error: “Task Not Found”}
